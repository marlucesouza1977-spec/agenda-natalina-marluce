// Configuração pública da Agenda Natalina. Nunca inclua senhas ou secret keys.
window.AGENDA_CONFIG = {
  supabaseUrl: 'https://rovpzyjamhmnwymdzlxn.supabase.co',
  supabasePublishableKey: 'sb_publishable_D4EsW3MbNF24JNIBQbeRYA_yym-jN1I'
};
